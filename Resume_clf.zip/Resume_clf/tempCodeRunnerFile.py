
            st.success(f"Predicted Category: {